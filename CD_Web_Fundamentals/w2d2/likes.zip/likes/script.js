// First Like Button

var count1 = 1;
var countElement1 = document.querySelector("#likes-counter1");
console.log(countElement1);

function add1()
{
    count1++;
    countElement1.innerText = count1 + " Like(s)";
    console.log(count);
}


// Second Like Button

var count2 = 1;
var countElement2 = document.querySelector("#likes-counter2");
console.log(countElement2);

function add2()
{
    count2++;
    countElement2.innerText = count2 + " Like(s)";
    console.log(count2);
}


// Third Like Button

var count3 = 1;
var countElement3 = document.querySelector("#likes-counter3");
console.log(countElement3);

function add3()
{
    count3++;
    countElement3.innerText = count3 + " Like(s)";
    console.log(count3);
}