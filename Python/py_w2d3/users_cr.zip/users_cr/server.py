from flask import Flask, render_template, redirect, request
app = Flask(__name__)
from users import Users


# our index route will handle rendering our form


@app.route('/')
def index():

    all_users = Users.get_all()

    return render_template("read_all.html", 
                            all_users=all_users)

# --------- Create User Page

@app.route('/create')
def Create_User():

    return render_template("create.html")

# -------- Create User ACTION

@app.route('/process', methods=['post'])
def NewUser():

    Users.Create(request.form)

    return redirect ('/')

if __name__ == "__main__":
    app.run(debug=True)

